let number = document.getElementById('num')
let entries = document.getElementById('preent')
let count = 0

function increment() {
    count += 1
    number.innerText = count
}

function decrement() {
    count -= 1
    if (count<0){
        count = 0
    }
    number.innerText = count
}

function reset() {
    count = 0
    number.innerText = count
}

function save() {
  let countStr = count + " - ";
  if (countStr.endsWith("- ")) {
    countStr = countStr.slice(0, -2);
  }
  if (entries.innerText === "Previous Entries:") {
    entries.innerText += " " + countStr;
  } else {
    entries.innerText += " - " + countStr;
  }
}

function cleartext() 
{
    entries.innerText = "Previous Entries:"
}